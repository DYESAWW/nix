/* =====================================================================
   Material 3 Expressive · Catppuccin Mocha (Mauve): theme.js
   Pairs with user.css. Everything is defensive: if an element is not found
   the script does nothing and user.css falls back to plain styling.

   1. Wavy seek bar        paints .me3-seek over Spotify's native progress bar
   2. Like state           data-me3-like="on|off" on every like / save button
   3. Carousel surfaces    data-me3-shelf on blocks that hold one heading + cards
   4. Play on artwork      one floating overlay over the hovered row's artwork

   Performance: the old version watched the WHOLE document and measured layout
   every 200 ms, which fought with the virtualised sidebar list while it
   scrolled. Now the observers only watch the main view and the player bar
   (never the sidebar), and nothing here reads layout except on hover.
   ===================================================================== */
(function me3Theme() {
  "use strict";

  const doc = document;
  const root = doc.documentElement;
  const $ = (sel, ctx = doc) => ctx.querySelector(sel);
  const $$ = (sel, ctx = doc) => Array.from(ctx.querySelectorAll(sel));
  const clamp01 = (n) => Math.min(1, Math.max(0, n));
  const player = () => (window.Spicetify && window.Spicetify.Player) || null;
  const libraryApi = () => {
    try { return window.Spicetify.Platform.LibraryAPI; } catch (_) { return null; }
  };

  function debounce(fn, ms) {
    let timer = 0;
    return () => {
      if (timer) return;
      timer = setTimeout(() => {
        timer = 0;
        try { fn(); } catch (_) { /* never let the theme break Spotify */ }
      }, ms);
    };
  }

  /* Anything the person did in the last 1.5 s may legitimately change a like. */
  let lastUserAction = 0;
  ["pointerdown", "keydown"].forEach((type) =>
    doc.addEventListener(type, () => { lastUserAction = performance.now(); }, true)
  );

  /* ------------------------------------------------------------------
     1. WAVY SEEK BAR
     ------------------------------------------------------------------ */
  const SEEK_HOST = ".playback-bar .playback-progressbar";
  const seek = {
    host: null,
    root: null,
    playing: false,
    dragging: false,
    dragValue: 0,
    holdUntil: 0,
    holdValue: 0,
    raf: 0,
  };

  function detectPlaying() {
    const p = player();
    if (p && typeof p.isPlaying === "function") return !!p.isPlaying();
    return !!$('[data-testid="control-button-playpause"][aria-label="Pause" i]');
  }

  function fractionFromPointer(e) {
    if (!seek.host) return 0;
    const r = seek.host.getBoundingClientRect();
    return r.width ? clamp01((e.clientX - r.left) / r.width) : 0;
  }

  function currentFraction() {
    if (seek.dragging) return seek.dragValue;
    if (performance.now() < seek.holdUntil) return seek.holdValue;

    const p = player();
    if (p && typeof p.getProgressPercent === "function") {
      const v = p.getProgressPercent();
      if (Number.isFinite(v)) return clamp01(v);
    }

    const fill = seek.host && $(".x-progressBar-fillColor, .x-progressBar-foreground", seek.host);
    if (fill) {
      const raw = getComputedStyle(fill).getPropertyValue("--progress-bar-transform").trim();
      const n = parseFloat(raw);
      if (Number.isFinite(n)) return clamp01(raw.endsWith("%") ? n / 100 : n);
    }
    return 0;
  }

  function setData(el, key, value) {
    if (el.dataset[key] !== value) el.dataset[key] = value;
  }

  function paintSeek() {
    const el = seek.root;
    if (!el || !el.isConnected) return;
    const f = currentFraction();
    el.style.setProperty("--p", f.toFixed(4));
    setData(el, "playing", seek.playing ? "true" : "false");
    setData(el, "dragging", seek.dragging ? "true" : "false");
    setData(el, "end", f > 0.985 ? "true" : "false");
  }

  function seekLoop() {
    paintSeek();
    const keepGoing = seek.playing || seek.dragging || performance.now() < seek.holdUntil;
    seek.raf = keepGoing ? requestAnimationFrame(seekLoop) : 0;
  }

  function kickSeek() {
    if (!seek.raf) seek.raf = requestAnimationFrame(seekLoop);
  }

  function onSeekPointerDown(e) {
    if (e.button !== 0 || !seek.host) return;
    seek.dragging = true;
    seek.dragValue = fractionFromPointer(e);

    const move = (ev) => { seek.dragValue = fractionFromPointer(ev); };
    const up = (ev) => {
      window.removeEventListener("pointermove", move, true);
      window.removeEventListener("pointerup", up, true);
      window.removeEventListener("pointercancel", up, true);
      seek.dragValue = fractionFromPointer(ev);
      seek.dragging = false;
      seek.holdValue = seek.dragValue;
      seek.holdUntil = performance.now() + 500;
      const p = player();
      if (p && typeof p.seek === "function") p.seek(seek.holdValue);
      kickSeek();
    };

    window.addEventListener("pointermove", move, true);
    window.addEventListener("pointerup", up, true);
    window.addEventListener("pointercancel", up, true);
    kickSeek();
  }

  function mountSeek() {
    const host = $(SEEK_HOST);
    if (!host) {
      root.classList.remove("me3-seek-ready");
      seek.host = seek.root = null;
      return;
    }
    if (host === seek.host && seek.root && seek.root.isConnected) return;

    seek.host = host;
    let el = $(":scope > .me3-seek", host);
    if (!el) {
      el = doc.createElement("div");
      el.className = "me3-seek";
      el.setAttribute("aria-hidden", "true");
      el.innerHTML =
        '<span class="me3-seek__active"><span class="me3-seek__wave"></span></span>' +
        '<span class="me3-seek__flat"></span>' +
        '<span class="me3-seek__track"></span>' +
        '<span class="me3-seek__thumb"></span>';
      host.appendChild(el);
    }
    seek.root = el;

    if (!host.__me3Bound) {
      host.__me3Bound = true;
      host.addEventListener("pointerdown", onSeekPointerDown, true);
    }

    root.classList.add("me3-seek-ready");
    seek.playing = detectPlaying();
    paintSeek();
    kickSeek();
  }

  /* ------------------------------------------------------------------
     2. LIKE STATE
        Every like / save button gets data-me3-like="on|off".
        - now-playing button: asked from Spotify's library API
        - track rows: asked from the library API by track URI (batched, cached)
        - everything else: read from the button itself
     ------------------------------------------------------------------ */
  const ROW_LIKE = [
    ".main-trackList-rowHeartButton",
    'button[data-testid="add-to-playlist-button"]',
    'button[aria-label="Add to playlist" i]',
    'button[aria-label="Add to Liked Songs" i]',
    'button[aria-label="Remove from Liked Songs" i]',
    'button[aria-label="Save to Your Library" i]',
    'button[aria-label="Remove from Your Library" i]',
  ].join(",");

  const OTHER_LIKE = [
    ".control-button-heart",
    ".main-addButton-button",
    'button[data-testid="add-button"]',
    'button[aria-label="Save to Your Library" i]',
    'button[aria-label="Add to Your Library" i]',
    'button[aria-label="Add to Liked Songs" i]',
    'button[aria-label="Remove from Your Library" i]',
    'button[aria-label="Remove from Liked Songs" i]',
  ].join(",");

  const ANY_LIKE_CLICK = ROW_LIKE + "," + OTHER_LIKE + ",.main-nowPlayingWidget-plusButton,.main-nowPlayingWidget-plusButton *";

  const previousLike = new WeakMap();
  const savedCache = new Map(); // track uri -> boolean

  function looksSaved(btn) {
    const label = (btn.getAttribute("aria-label") || "").toLowerCase();
    return (
      btn.classList.contains("main-addButton-active") ||
      btn.getAttribute("aria-checked") === "true" ||
      btn.getAttribute("aria-pressed") === "true" ||
      /textBrightAccent/.test(btn.className || "") ||
      /remove from|saved|added to|unlike|unsave/.test(label)
    );
  }

  function setLike(btn, saved) {
    const next = saved ? "on" : "off";
    const prev = previousLike.get(btn);
    if (prev === next) return;
    previousLike.set(btn, next);
    btn.setAttribute("data-me3-like", next);

    // Pop only right after a person's action, never on page load or song change.
    if (prev === "off" && next === "on" && performance.now() - lastUserAction < 1500) {
      btn.setAttribute("data-me3-pop", "");
      setTimeout(() => btn.removeAttribute("data-me3-pop"), 700);
    }
  }

  function nowPlayingLikeButton() {
    const widget =
      $(".main-nowPlayingWidget-nowPlaying") ||
      $('[data-testid="now-playing-widget"]') ||
      $(".main-nowPlayingBar-left");
    if (!widget) return null;

    const holder = $(".main-nowPlayingWidget-plusButton, .main-nowPlayingWidget-plusButtonWrapper, .control-button-heart", widget);
    if (holder) return holder.matches("button") ? holder : $("button", holder) || holder;

    return (
      $$("button", widget).find(
        (b) =>
          !b.closest(".main-coverSlotCollapsed-container") &&
          /liked|library|playlist|save|saved|add|remove|heart|like/i.test(b.getAttribute("aria-label") || "")
      ) || null
    );
  }

  async function savedByUris(uris) {
    const api = libraryApi();
    if (!api || !uris.length) return null;
    try {
      const result = await api.contains(...uris);
      return Array.isArray(result) ? result.map(Boolean) : null;
    } catch (_) {
      return null;
    }
  }

  async function syncNowPlayingLike() {
    const btn = nowPlayingLikeButton();
    if (!btn) return;
    const P = player();
    const item = P && P.data && (P.data.item || P.data.track);
    const res = item && item.uri ? await savedByUris([item.uri]) : null;
    setLike(btn, res ? res[0] : looksSaved(btn));
  }

  function trackUriOfRow(row) {
    const a = row.querySelector('a[href*="/track/"]');
    const m = a && /\/track\/([A-Za-z0-9]+)/.exec(a.getAttribute("href") || "");
    return m ? "spotify:track:" + m[1] : null;
  }

  let rowSyncBusy = false;
  async function syncRowLikes() {
    if (rowSyncBusy) return;
    rowSyncBusy = true;
    try {
      const items = [];
      const need = new Set();
      $$(".main-trackList-trackListRow").forEach((row) => {
        const btn = $(ROW_LIKE, row);
        if (!btn) return;
        const uri = trackUriOfRow(row);
        items.push({ btn, uri });
        if (uri && !savedCache.has(uri)) need.add(uri);
      });

      if (need.size) {
        const list = Array.from(need);
        const res = await savedByUris(list);
        if (res) list.forEach((uri, i) => savedCache.set(uri, res[i]));
      }

      items.forEach(({ btn, uri }) =>
        setLike(btn, uri && savedCache.has(uri) ? savedCache.get(uri) : looksSaved(btn))
      );
    } finally {
      rowSyncBusy = false;
    }
  }

  function syncOtherLikes() {
    const np = nowPlayingLikeButton();
    $$(OTHER_LIKE).forEach((btn) => {
      if (btn === np || btn.closest(".main-trackList-trackListRow")) return;
      setLike(btn, looksSaved(btn));
    });
  }

  function refreshAllLikes() {
    savedCache.clear();
    syncNowPlayingLike();
    syncRowLikes();
  }

  doc.addEventListener(
    "click",
    (e) => {
      if (e.target.closest && e.target.closest(ANY_LIKE_CLICK)) {
        setTimeout(refreshAllLikes, 300);
        setTimeout(refreshAllLikes, 1000);
      }
    },
    true
  );

  /* ------------------------------------------------------------------
     3. CAROUSEL SURFACES
        user.css already styles Spotify's own [data-shelf] / .main-shelf-shelf.
        This adds data-me3-shelf to any other block that holds a row of
        cards under exactly one <h2>, so every carousel gets its surface.
     ------------------------------------------------------------------ */
  const CARD_LINK = 'a[href^="/playlist/"], a[href^="/album/"], a[href^="/artist/"], a[href^="/show/"]';
  const NOT_A_SHELF_ZONE =
    '.main-trackList-trackList, .main-entityHeader-container, .main-actionBar-ActionBar, .main-topBar-container, [role="grid"]';
  const NOT_A_SHELF_BLOCK = ".main-trackList-trackList, .main-entityHeader-container, .main-actionBar-ActionBar";
  const shelfOfLink = new WeakMap();

  function resolveShelf(link) {
    let el = link.parentElement;
    for (let hops = 0; el && hops < 7; hops++, el = el.parentElement) {
      if (el.matches(".main-view-container, .Root__main-view, main")) return null;
      const headings = el.getElementsByTagName("h2").length;
      if (headings === 1) return el.querySelector(NOT_A_SHELF_BLOCK) ? null : el;
      if (headings > 1) return null;
    }
    return null;
  }

  function tagShelves() {
    const view = $(".main-view-container");
    if (!view) return;
    const shelves = new Set();

    $$(CARD_LINK, view).forEach((link) => {
      if (link.closest(NOT_A_SHELF_ZONE)) return;
      let shelf = shelfOfLink.get(link);
      if (!(shelf && shelf.isConnected && shelf.contains(link))) {
        shelf = resolveShelf(link);
        shelfOfLink.set(link, shelf);
      }
      if (shelf) shelves.add(shelf);
    });

    $$("[data-me3-shelf]", view).forEach((el) => {
      if (!shelves.has(el)) el.removeAttribute("data-me3-shelf");
    });
    shelves.forEach((el) => {
      if (!el.hasAttribute("data-me3-shelf")) el.setAttribute("data-me3-shelf", "");
    });
  }

  /* ------------------------------------------------------------------
     4. PLAY / PAUSE ON THE ARTWORK
        One floating overlay is placed over the artwork of the row under the
        pointer. A click on that artwork is forwarded to the row's own native
        play / pause button, so playback behaves exactly like Spotify's.
     ------------------------------------------------------------------ */
  const ART_SEL =
    ".main-trackList-rowSectionStart img, .main-trackList-rowSectionStart .main-trackList-rowImageFallback";
  const NATIVE_PLAY_SEL = [
    'button[aria-label^="Pause" i]',
    'button[aria-label^="Play" i]',
    ".main-trackList-rowPlayPauseButton",
    ".main-trackList-rowImagePlayPauseButton",
    ".main-trackList-rowImagePlayButton",
  ].join(",");

  const art = { el: null, glyph: null, row: null, busy: false, raf: 0 };

  function artOverlay() {
    if (!art.el) {
      const el = doc.createElement("div");
      el.className = "me3-art-play";
      el.setAttribute("aria-hidden", "true");
      el.innerHTML = '<span class="me3-art-play__glyph">play_arrow</span>';
      doc.body.appendChild(el);
      art.el = el;
      art.glyph = el.firstChild;
    }
    return art.el;
  }

  function hideArt() {
    art.row = null;
    if (art.el) art.el.classList.remove("is-visible");
  }

  function rowShowsPause(row) {
    const btn = $(NATIVE_PLAY_SEL, row);
    if (!btn) return false;
    return /^pause/i.test(btn.getAttribute("aria-label") || "") ||
      btn.classList.contains("main-trackList-rowImagePlayPauseButtonPlaying");
  }

  function updateArt() {
    if (!art.row) return;
    if (!art.row.isConnected) return hideArt();
    const img = $(ART_SEL, art.row);
    if (!img) return hideArt();

    const r = img.getBoundingClientRect();
    const view = $(".main-view-container");
    const v = view ? view.getBoundingClientRect() : { top: 0, bottom: window.innerHeight };
    // Hidden under the sticky top bar or scrolled out of the view
    if (!r.width || r.top < v.top + 64 || r.bottom > v.bottom) return hideArt();

    const el = artOverlay();
    el.style.left = r.left + "px";
    el.style.top = r.top + "px";
    el.style.width = r.width + "px";
    el.style.height = r.height + "px";

    const glyph = rowShowsPause(art.row) ? "pause" : "play_arrow";
    if (art.glyph.textContent !== glyph) art.glyph.textContent = glyph;
    el.classList.add("is-visible");
  }

  function scheduleArtUpdate() {
    if (art.raf || !art.row) return;
    art.raf = requestAnimationFrame(() => { art.raf = 0; updateArt(); });
  }

  doc.addEventListener(
    "mouseover",
    (e) => {
      const t = e.target;
      const row = t && t.closest ? t.closest(".main-trackList-trackListRow") : null;
      if (row === art.row) return;
      art.row = row;
      if (!row || !$(ART_SEL, row)) return hideArt();
      updateArt();
    },
    true
  );

  root.addEventListener("mouseleave", hideArt);
  doc.addEventListener("scroll", scheduleArtUpdate, true);
  window.addEventListener("resize", scheduleArtUpdate);

  doc.addEventListener(
    "click",
    (e) => {
      if (art.busy || !art.row || !art.row.isConnected || e.button !== 0) return;
      if (!art.row.contains(e.target)) return;
      const img = $(ART_SEL, art.row);
      if (!img) return;

      const r = img.getBoundingClientRect();
      if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) return;

      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();

      const btn = $(NATIVE_PLAY_SEL, art.row);
      art.busy = true;
      try {
        if (btn) btn.click();
        else art.row.dispatchEvent(new MouseEvent("dblclick", { bubbles: true, cancelable: true, view: window }));
      } finally {
        art.busy = false;
      }
      setTimeout(scheduleArtUpdate, 150);
      setTimeout(scheduleArtUpdate, 600);
    },
    true
  );

  function tagTrackLists() {
    $$(".main-trackList-trackList").forEach((list) => {
      const hasArtwork = !!list.querySelector(ART_SEL);
      if (hasArtwork !== list.hasAttribute("data-me3-art")) list.toggleAttribute("data-me3-art", hasArtwork);
    });
  }

  /* ------------------------------------------------------------------
     Wiring: observe ONLY the main view and the player bar
     ------------------------------------------------------------------ */
  const mainPass = debounce(() => {
    tagShelves();
    tagTrackLists();
    syncOtherLikes();
    syncRowLikes();
    scheduleArtUpdate();
  }, 250);

  const playerPass = debounce(() => {
    mountSeek();
    const np = nowPlayingLikeButton();
    if (np && !np.hasAttribute("data-me3-like")) syncNowPlayingLike();
  }, 150);

  const watched = new WeakSet();
  function watch(selector, handler) {
    const el = $(selector);
    if (!el || watched.has(el)) return;
    watched.add(el);
    new MutationObserver(handler).observe(el, { childList: true, subtree: true });
    handler();
  }

  function watchRoots() {
    watch(".Root__main-view", mainPass);
    watch(".Root__now-playing-bar", playerPass);
  }

  let apiBound = false;
  function bindSpicetify(tries = 0) {
    const S = window.Spicetify;
    if (!(S && S.Player && S.Platform)) {
      if (tries < 120) setTimeout(() => bindSpicetify(tries + 1), 300);
      return;
    }
    if (apiBound) return;
    apiBound = true;

    S.Player.addEventListener("onplaypause", () => {
      seek.playing = detectPlaying();
      paintSeek();
      kickSeek();
      scheduleArtUpdate();
    });
    S.Player.addEventListener("onprogress", paintSeek);
    S.Player.addEventListener("songchange", () => {
      seek.playing = detectPlaying();
      paintSeek();
      kickSeek();
      syncNowPlayingLike();
      scheduleArtUpdate();
    });

    try {
      libraryApi().getEvents().addListener("operation_complete", refreshAllLikes);
    } catch (_) { /* older clients: the click handler covers it */ }

    seek.playing = detectPlaying();
    refreshAllLikes();
  }

  function start() {
    watchRoots();
    setInterval(watchRoots, 2000); // roots can be re-created when layouts change
    bindSpicetify();
  }

  if (doc.body) start();
  else doc.addEventListener("DOMContentLoaded", start, { once: true });
})();
